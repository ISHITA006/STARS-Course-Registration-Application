import json
f = open('full_mods_v2.json', "r")
mod_json = json.loads(f.read())

filtered_dict = {'COURSES':[]}
count = 0
for course in mod_json['COURSES']:
    if 'CE' in course['COURSE']:
        filtered_dict['COURSES'].append(course)
        count += 1

print("Number of CE courses filtered:",count)

with open("only_ce_mods.json", "w") as outfile:
    json.dump(filtered_dict, outfile)